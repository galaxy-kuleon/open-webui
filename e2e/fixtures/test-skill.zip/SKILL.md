---
name: Test Skill
description: E2E test fixture for skill-zip-import.spec.ts
---

# Test Skill

This is a minimal SKILL.md used by the E2E skill-zip-import test.
